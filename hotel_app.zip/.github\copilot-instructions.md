# AI Hotel Management System - Copilot Instructions

## Overview
This project is a simple Hotel Management System that allows users to view and book rooms. The architecture consists of an HTML front-end, a CSS stylesheet for styling, and a JavaScript file for dynamic content management.

## Architecture
- **index.html**: The main entry point of the application. It links to the CSS and JavaScript files and contains the structure for displaying available rooms.
- **style.css**: Contains styles for the body, container, and room elements, ensuring a clean and user-friendly interface.
- **script.js**: Manages the dynamic loading of room data and handles user interactions such as booking a room.

## Developer Workflows
- **Building**: Simply open `index.html` in a web browser to view the application. No build tools are required.
- **Testing**: Manual testing is performed by interacting with the UI. Ensure that all buttons and dynamic content load correctly.
- **Debugging**: Use browser developer tools (F12) to inspect elements and debug JavaScript errors.

## Project-Specific Conventions
- Use of ES6 syntax in JavaScript (e.g., template literals for HTML generation).
- CSS classes are used to style components consistently across the application.

## Integration Points
- The JavaScript file fetches room data from a hardcoded array. Future enhancements could include fetching data from a server or database.
- The application is designed to be easily extendable; additional features like user authentication or payment processing can be integrated in the future.

## Key Files
- **[index.html](../index.html)**: Main HTML structure.
- **[style.css](../style.css)**: Styles for the application.
- **[script.js](../script.js)**: JavaScript logic for dynamic content.

---

This document serves as a guide for AI agents to understand the structure and functionality of the Hotel Management System, enabling them to assist effectively in development and enhancements.